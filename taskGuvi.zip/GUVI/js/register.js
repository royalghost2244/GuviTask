$(document).ready(function () {
  $("#registerBtn").click(function () {
    var username = $("#username").val();
    var password = $("#password").val();
    var r_password = $("#r_password").val();

    $.ajax({
      type: "POST",
      url: "php/register.php",
      data: {
        username: username,
        password: password,
        r_password: r_password,
      },
      success: function (response) {
        console.log(response);
        if (response === "Success") {
          window.location.href = "login.html";
        } else {
          alert(response);
        }
      },
      error: function (error) {
        console.log(error);
      },
    });
  });
});

function togglePasswordVisibility(inputId, iconId) {
  const passwordInput = document.getElementById(inputId);
  const passwordIcon = document.getElementById(iconId);

  if (passwordInput.type === "password") {
    passwordInput.type = "text";
    passwordIcon.textContent = "👁️";
  } else {
    passwordInput.type = "password";
    passwordIcon.textContent = "🔒";
  }
}
