<?php

require "../vendor/autoload.php";
$mongoClient = new MongoDB\Client("mongodb://localhost:27017");
$database = $mongoClient->selectDatabase("myDB");
$collection = $database->selectCollection("profile");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $profileDetails = $_POST["profileDetails"];


    try {
        $result = $collection->insertOne($profileDetails);
        echo "Success";
    } catch (Exception $e) {
        echo "Error: " . $e->getMessage();
    }
}
?>
