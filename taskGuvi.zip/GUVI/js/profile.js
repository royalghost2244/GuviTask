$(document).ready(function () {
  const urlParams = new URLSearchParams(window.location.search);
  const username = urlParams.get("username");

  console.log("Username:", username);

  $("#updateProfileBtn").click(function () {
    var profileDetails = {
      Username: username,
      firstName: $("#firstName").val(),
      lastName: $("#lastName").val(),
      contact: $("#contact").val(),
      dob: $("#dob").val(),
      gender: $("#gender").val(),
      email: $("#email").val(),
    };

    $.ajax({
      type: "POST",
      url: "php/profile.php",
      data: {
        profileDetails: profileDetails,
      },
      success: function (response) {
        if (response === "Success") {
          alert("Profile updated successfully!");
        } else {
          alert(response);
        }
      },
      error: function (error) {
        console.log(error);
      },
    });
  });
});
