$(document).ready(function () {
  $("#loginBtn").click(function () {
    var username = $("#username").val();
    var password = $("#password").val();

    $.ajax({
      type: "POST",
      url: "php/login.php",
      data: {
        username: username,
        password: password,
      },
      success: function (response) {
        if (response === "Success") {
          window.location.href =
            "profile.html?username=" + encodeURIComponent(username);
        } else {
          alert(response);
        }
      },
      error: function (error) {
        console.log(error);
      },
    });
  });
});
